/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package braino;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dell
 */
public class ActualGameIT {

    public ActualGameIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
        System.out.println("All tests have run successfully!");
    }

    @Test
    public void testCheckCorrectness1() {
        System.out.println("checkCorrectness: if the two values are equal and he clicked yes then it is true.");
        String userAnswer = "Yes";
        ActualGame instance = new ActualGame();
        instance.setIndex1(1);
        instance.setIndex3(1);
        boolean result = instance.checkCorrectness(userAnswer);
        assertTrue(result);

    }

    @Test
    public void testCheckCorrectness2() {
        System.out.println("checkCorrectness: if the two values are not  equal and he clicked yes then it is false.");
        String userAnswer = "Yes";
        ActualGame instance = new ActualGame();
        instance.setIndex1(1);
        instance.setIndex3(2);
        boolean result = instance.checkCorrectness(userAnswer);
        assertFalse(result);

    }

    @Test
    public void testCheckCorrectness3() {
        System.out.println("checkCorrectness: if the two values are not equal and he clicked no then it is true.");
        String userAnswer = "No";
        ActualGame instance = new ActualGame();
        instance.setIndex1(1);
        instance.setIndex3(2);
        boolean result = instance.checkCorrectness(userAnswer);
        assertTrue(result);

    }

    @Test
    public void testCheckCorrectness4() {
        System.out.println("checkCorrectness: if the two values are equal and he clicked no then it is false.");
        String userAnswer = "No";
        ActualGame instance = new ActualGame();
        instance.setIndex1(1);
        instance.setIndex3(1);
        boolean result = instance.checkCorrectness(userAnswer);
        assertFalse(result);

    }

}
