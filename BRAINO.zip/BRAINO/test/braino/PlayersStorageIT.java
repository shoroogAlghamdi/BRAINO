/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package braino;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dell
 */
public class PlayersStorageIT {
    
    static PlayersStorage instance;
    
    public PlayersStorageIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        instance = new PlayersStorage();
        PlayerInfo newPlayer1 = new PlayerInfo("Shoroog", "1234", 2, 100);
        PlayerInfo newPlayer2 = new PlayerInfo("Layan", "123", 1, 50);
        PlayerInfo newPlayer3 = new PlayerInfo("Alanoud", "12", 1, 0);
        instance.addPlayer(newPlayer3);
        instance.addPlayer(newPlayer1);
        instance.addPlayer(newPlayer2);
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
        System.out.println("All tests have run successfully!");
    }

    @Test
    public void testAddPlayer() {
        System.out.println("addPlayer: checks that the player is added successfully.");
        PlayerInfo newPlayer = new PlayerInfo("Sara", "345", 1, 0);
        instance.addPlayer(newPlayer);
        PlayerInfo registeredPlayer = instance.getPlayer("Sara", "345");
        assertNotNull(registeredPlayer);
    }
    
    @Test
    public void testGetPlayer1() {
        System.out.println("getPlayer: checks that the player info are stored in the system.");
        String userName = "Alanoud";
        String password = "12";
        PlayerInfo result = instance.getPlayer(userName, password);
        assertNotNull(result);
    }
    
    @Test
    public void testGetPlayer2() {
        System.out.println("getPlayer: checks that the player info are not stored in the system.");
        String userName = "Samar";
        String password = "789";
        PlayerInfo result = instance.getPlayer(userName, password);
        assertNull(result);
    }
    
    @Test
    public void testLogin1() {
        System.out.println("verifyRegestredUser: check that the player is registered in the system and he can login.");
        PlayerInfo newPlayer = new PlayerInfo("Shoroog", "1234", 2, 100);
        boolean result = instance.verifyRegestredUser(newPlayer);
        assertTrue(result);
    }
    
    @Test
    public void testLogin2() {
        System.out.println("verifyRegestredUser: check that the player is registered in the system, but due to wrong password he cannot login.");
        PlayerInfo newPlayer = new PlayerInfo("Shoroog", "123", 2, 100);
        boolean result = instance.verifyRegestredUser(newPlayer);
        assertFalse(result);
    }
    
    @Test
    public void testLogin3() {
        System.out.println("verifyRegestredUser: check that the player is registered in the system, but due to wrong username he cannot login.");
        PlayerInfo newPlayer = new PlayerInfo("Shoug", "1234", 2, 100);
        boolean result = instance.verifyRegestredUser(newPlayer);
        assertFalse(result);
    }
    
    @Test
    public void testLogin4() {
        System.out.println("verifyRegestredUser: check that the player is not registered in the system, so he cannot login.");
        PlayerInfo newPlayer = new PlayerInfo("Farah", "324", 2, 100);
        PlayersStorage instance = new PlayersStorage();
        boolean result = instance.verifyRegestredUser(newPlayer);
        assertFalse(result);
    }
    
    @Test
    public void testSignUp1() {
        System.out.println("verifyUnregestredUser: check that the user is already registered in the system so he cannot sign up.");
        PlayerInfo newPlayer = new PlayerInfo("Layan", "123", 1, 50);
        boolean result = instance.verifyUnregestredUser(newPlayer);
        assertFalse(result);
    }
    
    @Test
    public void testSignUp2() {
        System.out.println("verifyUnregestredUser: check that the user is not registered in the system so he can sign up.");
        PlayerInfo newPlayer = new PlayerInfo("Ghada", "6543", 2, 50);
        boolean result = instance.verifyUnregestredUser(newPlayer);
        assertTrue(result);
    }
    
}
