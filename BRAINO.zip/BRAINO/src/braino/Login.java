package braino;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    boolean userNameFound = false;
    boolean passwordFound = false;
    String score = "";
    public static String userNameStored;
    String passwordStored;
    String range;

    public Login() {
        initComponents();
        setLocationRelativeTo(null);
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
        logoLabel.setLocation(new java.awt.Point(106, 23));
        userName.setBackground(new java.awt.Color(0, 0, 0, 1));
        password.setBackground(new java.awt.Color(0, 0, 0, 1));

        for (int j = 0; j < SignUp.storage.allPlayers.size(); j++) {
            System.out.println(SignUp.storage.allPlayers.get(j));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        loginButton = new keeptoo.KButton();
        userName = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        logoLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        signUp = new keeptoo.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loginButton.setForeground(new java.awt.Color(70, 94, 136));
        loginButton.setText("Login");
        loginButton.setBorderPainted(false);
        loginButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        loginButton.setkBorderRadius(20);
        loginButton.setkEndColor(new java.awt.Color(96, 179, 178));
        loginButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        loginButton.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        loginButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        loginButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        loginButton.setkStartColor(new java.awt.Color(70, 94, 136));
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(loginButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 150, 50));

        userName.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        userName.setForeground(new java.awt.Color(70, 94, 136));
        userName.setText("User Name");
        userName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(70, 94, 136)));
        userName.setOpaque(false);
        kGradientPanel1.add(userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, 408, 30));

        password.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        password.setForeground(new java.awt.Color(70, 94, 136));
        password.setText("Password");
        password.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(70, 94, 136)));
        password.setOpaque(false);
        kGradientPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 330, 408, 30));
        kGradientPanel1.add(logoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 23, 458, 143));

        jLabel1.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(201, 53, 96));
        jLabel1.setText("Already a user?");
        kGradientPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, -1, -1));

        jLabel2.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(70, 94, 136));
        jLabel2.setText("Not a user?");
        kGradientPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 370, -1, -1));

        signUp.setBackground(new java.awt.Color(0,0,0,0));
        signUp.setBorder(null);
        signUp.setForeground(new java.awt.Color(70, 94, 136));
        signUp.setText("Sign Up!");
        signUp.setActionCommand("");
        signUp.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        signUp.setkAllowGradient(false);
        signUp.setkBackGroundColor(new java.awt.Color(0,0,0,0));
        signUp.setkEndColor(new java.awt.Color(0,0,0,0));
        signUp.setkFillButton(false);
        signUp.setkForeGround(new java.awt.Color(70, 94, 136));
        signUp.setkHoverForeGround(new java.awt.Color(70, 94, 136));
        signUp.setkHoverStartColor(new java.awt.Color(0,0,0,0));
        signUp.setkPressedColor(new java.awt.Color(0,0,0,0));
        signUp.setkSelectedColor(new java.awt.Color(70, 94, 136));
        signUp.setkStartColor(new java.awt.Color(0,0,0,0));
        signUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signUpActionPerformed(evt);
            }
        });
        kGradientPanel1.add(signUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 368, 70, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        PlayerInfo player = new PlayerInfo(this.userName.getText().toString(), this.password.getText().toString());
        if (SignUp.storage.verifyRegestredUser(player)) {
            player = SignUp.storage.getPlayer(this.userName.getText().toString(), this.password.getText().toString());
            new PlayerInfoFrame(player).setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(this, "Please enter correct user name and passowrd or sign up!");
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void signUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signUpActionPerformed
        new RangeSelection().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_signUpActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KButton loginButton;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPasswordField password;
    private keeptoo.KButton signUp;
    private javax.swing.JTextField userName;
    // End of variables declaration//GEN-END:variables
}
