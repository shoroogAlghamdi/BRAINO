/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package braino;

import java.awt.Color;

/**
 *
 * @author Dell
 */
public class ActualGame {
    
    String meaning,randomColor;
    Color inkColor;
    // meaning
    int index1;
    // ink word
    int index2;
    // ink color
    int index3;
    boolean answer = false;

    public ActualGame() {
    }

    public void setRandomIndex1() {
        this.index1 =(int) (Math.random() * 5);;
    }

    public void setRandomIndex2() {
        this.index2 = (int) (Math.random() * 5);
    }

    public void setRandomIndex3() {
        this.index3 = (int) (Math.random() * 5);
    }

    public void setIndex1(int index1) {
        this.index1 = index1;
    }

    public void setIndex2(int index2) {
        this.index2 = index2;
    }

    public void setIndex3(int index3) {
        this.index3 = index3;
    }
    
    public String determineMeaning(String [] meaningsArray) {
        this.setRandomIndex1();
        return this.meaning = meaningsArray[this.index1];
    }

    public String determineRandomColor(String [] randomColors) {
        this.setRandomIndex2();
        return this.randomColor = randomColors[this.index2];
    }

    public Color determineInkColor(Color [] inkColors) {
        this.setRandomIndex3();
        return this.inkColor = inkColors[this.index3];
    }
    
    //--------------------------------------------------------------------------
    public boolean checkCorrectness(String userAnswer){
        if(userAnswer.equalsIgnoreCase("Yes"))
            return this.getIndex1() == this.getIndex3();
        
        
        if(userAnswer.equalsIgnoreCase("No"))
            return this.getIndex1() != this.getIndex3();
        
        return false;
    }
    public int getIndex1() {
        return index1;
    }

    public int getIndex2() {
        return index2;
    }

    public int getIndex3() {
        return index3;
    }

    
    
    
      
}
