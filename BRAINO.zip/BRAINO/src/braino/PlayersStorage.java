/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package braino;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class PlayersStorage {

    ArrayList<PlayerInfo> allPlayers = new ArrayList<>();

    public ArrayList<PlayerInfo> getPlayersInfo() {
        return allPlayers;
    }

    public void addPlayer(PlayerInfo newPlayer) {
        this.allPlayers.add(newPlayer);
    }

    public PlayerInfo getPlayer(String userName, String password) {
        for (int i = 0; i < this.allPlayers.size(); i++) {
            if ((this.allPlayers.get(i).getUserName().equalsIgnoreCase(userName)) && (this.allPlayers.get(i).getPassword().equalsIgnoreCase(password))) {
                return this.allPlayers.get(i);
            }
        }
        return null;
    }

    public void setPlayers(ArrayList<PlayerInfo> players) {
        this.allPlayers = players;
    }

    // to be used in login
    public boolean verifyRegestredUser(PlayerInfo newPlayer) {
        for (int i = 0; i < this.allPlayers.size(); i++) {
            if ((this.allPlayers.get(i).getUserName().equalsIgnoreCase(newPlayer.getUserName())) && (this.allPlayers.get(i).getPassword().equalsIgnoreCase(newPlayer.getPassword()))) {
                return true;
            }
        }
        return false;
    }

    // to be used in signup
    public boolean verifyUnregestredUser(PlayerInfo newPlayer) {
        for (int i = 0; i < this.allPlayers.size(); i++) {
            if ((this.allPlayers.get(i).getUserName().equalsIgnoreCase(newPlayer.getUserName())) && (this.allPlayers.get(i).getPassword().equalsIgnoreCase(newPlayer.getPassword()))) {
                return false;
            }
        }
        return true;
    }

}
