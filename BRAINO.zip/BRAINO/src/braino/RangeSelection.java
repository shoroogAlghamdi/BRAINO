package braino;

import com.sun.prism.paint.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.ImageIcon;

public class RangeSelection extends javax.swing.JFrame {

    int range = 0;

    public RangeSelection() {
        initComponents();
        setLocationRelativeTo(null);
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
        logoLabel.setLocation(new java.awt.Point(106, 23));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        logoLabel = new javax.swing.JLabel();
        alreadyUser = new javax.swing.JLabel();
        childButton = new keeptoo.KButton();
        teenagerButton = new keeptoo.KButton();
        adultButton = new keeptoo.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));

        alreadyUser.setFont(new java.awt.Font("Courier New", 1, 30)); // NOI18N
        alreadyUser.setForeground(new java.awt.Color(201, 53, 96));
        alreadyUser.setText("Select Your Range");

        childButton.setBackground(new java.awt.Color(70, 94, 136));
        childButton.setText("Child (10-13)");
        childButton.setBorderPainted(false);
        childButton.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        childButton.setkAllowGradient(false);
        childButton.setkBackGroundColor(new java.awt.Color(70, 94, 136));
        childButton.setkBorderRadius(20);
        childButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        childButton.setkHoverForeGround(new java.awt.Color(70, 94, 136));
        childButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        childButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        childButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                childButtonActionPerformed(evt);
            }
        });

        teenagerButton.setText("Teenager (14-18)");
        teenagerButton.setBorderPainted(false);
        teenagerButton.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        teenagerButton.setkBorderRadius(20);
        teenagerButton.setkEndColor(new java.awt.Color(174, 206, 162));
        teenagerButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        teenagerButton.setkHoverForeGround(new java.awt.Color(70, 94, 136));
        teenagerButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        teenagerButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        teenagerButton.setkStartColor(new java.awt.Color(78, 163, 181));
        teenagerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teenagerButtonActionPerformed(evt);
            }
        });

        adultButton.setText("Adult (Above 18)");
        adultButton.setBorderPainted(false);
        adultButton.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        adultButton.setkAllowGradient(false);
        adultButton.setkBackGroundColor(new java.awt.Color(174, 206, 162));
        adultButton.setkBorderRadius(20);
        adultButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        adultButton.setkHoverForeGround(new java.awt.Color(70, 94, 136));
        adultButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        adultButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        adultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adultButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap(125, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(alreadyUser)
                        .addGap(193, 193, 193))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100))))
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(237, 237, 237)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(adultButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(teenagerButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(childButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(alreadyUser)
                .addGap(28, 28, 28)
                .addComponent(childButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(teenagerButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adultButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(107, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void childButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_childButtonActionPerformed
        range = 1;
        new SignUp(range).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_childButtonActionPerformed

    private void teenagerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teenagerButtonActionPerformed
        range = 2;
        new SignUp(range).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_teenagerButtonActionPerformed

    private void adultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adultButtonActionPerformed
        range = 3;
        new SignUp(range).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_adultButtonActionPerformed

    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RangeSelection().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KButton adultButton;
    private javax.swing.JLabel alreadyUser;
    private keeptoo.KButton childButton;
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel logoLabel;
    private keeptoo.KButton teenagerButton;
    // End of variables declaration//GEN-END:variables
}
