package braino;

import com.sun.prism.paint.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class GameOver extends javax.swing.JFrame {

    PlayerInfo player;
    
    public GameOver(PlayerInfo player) {
        
        initComponents();
        setLocationRelativeTo(null);
        this.player =player;
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
         logoLabel.setLocation(new java.awt.Point(106,23));
        ImageIcon gameOver = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("GameOver.png")));
        Image img3 = gameOver.getImage();
        Image img4 = img3.getScaledInstance(overPic.getWidth(), overPic.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(img4);
        overPic.setIcon(i2);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        logoLabel = new javax.swing.JLabel();
        GameOverButton = new keeptoo.KButton();
        overPic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));

        GameOverButton.setForeground(new java.awt.Color(70, 94, 136));
        GameOverButton.setText("Game over");
        GameOverButton.setBorderPainted(false);
        GameOverButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        GameOverButton.setkBorderRadius(20);
        GameOverButton.setkEndColor(new java.awt.Color(78, 163, 181));
        GameOverButton.setkHoverEndColor(new java.awt.Color(78, 163, 181));
        GameOverButton.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        GameOverButton.setkHoverStartColor(new java.awt.Color(78, 163, 181));
        GameOverButton.setkPressedColor(new java.awt.Color(78, 163, 181));
        GameOverButton.setkStartColor(new java.awt.Color(70, 94, 136));
        GameOverButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GameOverButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(GameOverButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(257, 257, 257))
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(kGradientPanel1Layout.createSequentialGroup()
                        .addGap(240, 240, 240)
                        .addComponent(overPic, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(100, 100, 100))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(overPic, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(GameOverButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GameOverButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GameOverButtonActionPerformed
        new PlayerInfoFrame(player).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_GameOverButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameOver(null).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KButton GameOverButton;
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel overPic;
    // End of variables declaration//GEN-END:variables
}
