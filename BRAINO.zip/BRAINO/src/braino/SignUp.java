package braino;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class SignUp extends javax.swing.JFrame {

    int range;
    int score = 0;
    
    public static PlayersStorage storage = new PlayersStorage();

    public SignUp(int range) {
        initComponents();
        setLocationRelativeTo(null);
        this.range = range;
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
        logoLabel.setLocation(new java.awt.Point(106, 23));
        userName.setBackground(new java.awt.Color(0, 0, 0, 1));
        password.setBackground(new java.awt.Color(0, 0, 0, 1));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        signUpButton = new keeptoo.KButton();
        userName = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        logoLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        signUpButton.setForeground(new java.awt.Color(70, 94, 136));
        signUpButton.setText("Sign Up");
        signUpButton.setBorderPainted(false);
        signUpButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        signUpButton.setkBorderRadius(20);
        signUpButton.setkEndColor(new java.awt.Color(96, 179, 178));
        signUpButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        signUpButton.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        signUpButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        signUpButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        signUpButton.setkStartColor(new java.awt.Color(70, 94, 136));
        signUpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signUpButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(signUpButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 150, 50));

        userName.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        userName.setForeground(new java.awt.Color(70, 94, 136));
        userName.setText("User Name");
        userName.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(70, 94, 136)));
        userName.setOpaque(false);
        kGradientPanel1.add(userName, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, 408, 30));

        password.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        password.setForeground(new java.awt.Color(70, 94, 136));
        password.setText("Password");
        password.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(70, 94, 136)));
        password.setOpaque(false);
        kGradientPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 330, 408, 30));
        kGradientPanel1.add(logoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 23, 458, 143));

        jLabel1.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(201, 53, 96));
        jLabel1.setText("Enter your info:");
        kGradientPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void signUpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signUpButtonActionPerformed
        PlayerInfo newPlayer = new PlayerInfo(this.userName.getText().toString(), this.password.getText().toString(), this.range, score);
        if (storage.verifyUnregestredUser(newPlayer)) {
            storage.addPlayer(newPlayer);
        } else {
            JOptionPane.showMessageDialog(this, "This account is already registered! Please, login.");
        }
        new Login().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_signUpButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUp(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JPasswordField password;
    private keeptoo.KButton signUpButton;
    private javax.swing.JTextField userName;
    // End of variables declaration//GEN-END:variables
}
