package braino;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.Scanner;
import java.util.TimerTask;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Game extends javax.swing.JFrame {

    String score;
    boolean answer;
    Scanner input;
    boolean isYes = false;
    boolean isNo = false;
    String[] meaningArray = {"BLUE", "GREEN", "RED", "YELLOW", "BLACK"};
    String[] randomColors = {"BLUE", "GREEN", "RED", "YELLOW", "BLACK"};
    Color[] inkColorArray = {Color.BLUE, Color.GREEN, Color.RED, Color.YELLOW, Color.BLACK,};

    ActualGame g = new ActualGame();
    int questionCounter = 1;
    int timeCounter = 0;
    int questionsLimit;
    int timerLimit;
    boolean isIT = false;
    boolean disabled = false;
    PlayerInfo player;
    boolean paused = false;

    public Game(PlayerInfo player) {
        initComponents();
        setLocationRelativeTo(null);
        this.player = player;
        ImageIcon imm = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("1.png")));
        Image img1 = imm.getImage();
        Image img2 = img1.getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        jLabel3.setIcon(i);
        this.questionNo.setText("#1");

        randomSelection();
        startPlaying();
        defineGameLevel(player.getRange());
    }

    public void defineGameLevel(int range) {
        switch (range) {
            case 1:
                questionsLimit = 25;
                timerLimit = 240;
                break;
            case 2:
                questionsLimit = 50;
                timerLimit = 180;
                break;
            case 3:
                questionsLimit = 100;
                timerLimit = 60;
                break;
            default:
                break;
        }
    }

    public void startPlaying() {
        java.util.Timer timer = new java.util.Timer();
        timeCounter = 1;
        TimerTask task = new TimerTask() {
            public void run() {
                if (!disabled) {
                    if (timeCounter < 10) {
                        time.setText("00:0" + Integer.toString(timeCounter));
                    } else {
                        time.setText("00:" + Integer.toString(timeCounter));
                    }
                    timeCounter++;
                    if (timeCounter == 61) {
                        timer.cancel();
                        new GameOver(player).setVisible(true);

                    } else if (isIT) {
                        timer.cancel();
                        isIT = false;
                    }
                }
            }
        };
        timer.scheduleAtFixedRate(task, 1000, 1000);
    }

    public void randomSelection() {
        this.meaningLabel.setText(g.determineMeaning(meaningArray));
        this.inkColorLabel.setText(g.determineRandomColor(randomColors));
        this.inkColorLabel.setForeground(g.determineInkColor(inkColorArray));
        this.remove(this.meaningLabel);
        this.remove(this.inkColorLabel);
        this.revalidate();
        this.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        pauseButton = new keeptoo.KButton();
        jLabel3 = new javax.swing.JLabel();
        meaning = new javax.swing.JLabel();
        meaningLabel = new javax.swing.JLabel();
        inkColor = new javax.swing.JLabel();
        inkColorLabel = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        noButton = new keeptoo.KButton();
        yesButton = new keeptoo.KButton();
        questionNo = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        score1 = new javax.swing.JLabel();
        socreValue = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(96, 179, 178));
        kGradientPanel1.setkStartColor(new java.awt.Color(70, 94, 136));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pauseButton.setText("||");
        pauseButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        pauseButton.setkAllowGradient(false);
        pauseButton.setkBackGroundColor(new java.awt.Color(96, 179, 178));
        pauseButton.setkBorderRadius(40);
        pauseButton.setkSelectedColor(new java.awt.Color(70, 94, 136));
        pauseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pauseButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(pauseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 13, 30, 30));
        kGradientPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 8, 680, 40));

        meaning.setBackground(new java.awt.Color(117, 178, 160));
        meaning.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        meaning.setForeground(new java.awt.Color(70, 94, 136));
        meaning.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        meaning.setText("Meaning");
        meaning.setOpaque(true);
        kGradientPanel1.add(meaning, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 460, -1));

        meaningLabel.setBackground(new java.awt.Color(255, 255, 255));
        meaningLabel.setFont(new java.awt.Font("Courier New", 1, 48)); // NOI18N
        meaningLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        meaningLabel.setOpaque(true);
        kGradientPanel1.add(meaningLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 460, 90));

        inkColor.setBackground(new java.awt.Color(117, 178, 160));
        inkColor.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        inkColor.setForeground(new java.awt.Color(70, 94, 136));
        inkColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inkColor.setText("Ink color");
        inkColor.setOpaque(true);
        kGradientPanel1.add(inkColor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 350, 460, -1));

        inkColorLabel.setBackground(new java.awt.Color(255, 255, 255));
        inkColorLabel.setFont(new java.awt.Font("Courier New", 1, 48)); // NOI18N
        inkColorLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        inkColorLabel.setOpaque(true);
        kGradientPanel1.add(inkColorLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 460, 90));

        jLabel4.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Does the meaning match the ink color? ");
        kGradientPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, -1, 22));

        noButton.setForeground(new java.awt.Color(70, 94, 136));
        noButton.setText("No");
        noButton.setBorderPainted(false);
        noButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        noButton.setkAllowGradient(false);
        noButton.setkBackGroundColor(new java.awt.Color(175, 208, 162));
        noButton.setkBorderRadius(20);
        noButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        noButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(noButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 460, 310, -1));

        yesButton.setForeground(new java.awt.Color(70, 94, 136));
        yesButton.setText("Yes");
        yesButton.setBorderPainted(false);
        yesButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        yesButton.setkAllowGradient(false);
        yesButton.setkBackGroundColor(new java.awt.Color(175, 208, 162));
        yesButton.setkBorderRadius(20);
        yesButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        yesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yesButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(yesButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 330, -1));

        questionNo.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        questionNo.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel1.add(questionNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, -1, -1));

        time.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        time.setForeground(new java.awt.Color(255, 255, 255));
        time.setText("00:");
        kGradientPanel1.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, -1, -1));

        score1.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        score1.setForeground(new java.awt.Color(255, 255, 255));
        score1.setText("Score");
        kGradientPanel1.add(score1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, -1, -1));

        socreValue.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        socreValue.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel1.add(socreValue, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pauseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pauseButtonActionPerformed
        if (!paused) {
            this.yesButton.setEnabled(false);
            this.noButton.setEnabled(false);
            this.pauseButton.revalidate();
            this.pauseButton.repaint();
            paused = true;
            disabled = true;
        } else {
            paused = false;
            disabled = false;
            this.yesButton.setEnabled(true);
            this.noButton.setEnabled(true);
        }
    }//GEN-LAST:event_pauseButtonActionPerformed

    private void yesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yesButtonActionPerformed

        this.answer = g.checkCorrectness("Yes");
        if (answer) {
            modifyScore();
        }
        if (questionCounter < questionsLimit && timeCounter < timerLimit) {
            displayNextQuestion();
        }

        if (player.getRange() == 1 && questionCounter == questionsLimit && timeCounter < timerLimit) {
            smartChild();
        }

    }//GEN-LAST:event_yesButtonActionPerformed

    private void noButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noButtonActionPerformed
        this.answer = g.checkCorrectness("No");
        if (answer) {
            modifyScore();
        }

        if (questionCounter < questionsLimit && timeCounter < timerLimit) {
            displayNextQuestion();
        }

        if (player.getRange() == 1 && questionCounter == questionsLimit && timeCounter < timerLimit) {
            smartChild();
        }
    }//GEN-LAST:event_noButtonActionPerformed

    public void smartChild() {
        JOptionPane.showMessageDialog(this, "You got smart! We wil level up the challenge, click ok to get smarter!");
        questionsLimit = 50;
        timerLimit = 180;
        timeCounter = 0;
        questionCounter = 1;
        randomSelection();
        questionNo.setText("#" + Integer.toString(questionCounter));
        this.remove(questionNo);
        this.revalidate();
        this.repaint();
    }

    public void modifyScore() {
        this.player.setScore(this.player.getScore() + 10);
        socreValue.setText("#" + Integer.toString(this.player.getScore()));
        this.remove(socreValue);
        this.revalidate();
        this.repaint();
    }

    public void displayNextQuestion() {
        randomSelection();
        questionCounter++;
        questionNo.setText("#" + Integer.toString(questionCounter));
        this.remove(questionNo);
        this.revalidate();
        this.repaint();
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Game(null).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel inkColor;
    private javax.swing.JLabel inkColorLabel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel meaning;
    private javax.swing.JLabel meaningLabel;
    private keeptoo.KButton noButton;
    private keeptoo.KButton pauseButton;
    private javax.swing.JLabel questionNo;
    private javax.swing.JLabel score1;
    private javax.swing.JLabel socreValue;
    private javax.swing.JLabel time;
    private keeptoo.KButton yesButton;
    // End of variables declaration//GEN-END:variables
}
