package braino;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class PlayerInfoFrame extends javax.swing.JFrame {

    PlayerInfo player;

    public PlayerInfoFrame(PlayerInfo player) {
        initComponents();
        setLocationRelativeTo(null);
        this.player = player;
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
        logoLabel.setLocation(new java.awt.Point(106, 23));
        ImageIcon userLogo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("user.png")));
        Image img3 = userLogo.getImage();
        Image img4 = img3.getScaledInstance(playerLogo.getWidth(), playerLogo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i2 = new ImageIcon(img4);
        playerLogo.setIcon(i2);
        
        this.playerUserName.setText(this.playerUserName.getText() + player.getUserName());
        this.playerScore.setText(this.playerScore.getText() + player.getScore());
        

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        logoLabel = new javax.swing.JLabel();
        playerUserName = new javax.swing.JLabel();
        playButton = new keeptoo.KButton();
        playerScore = new javax.swing.JLabel();
        playerLogo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));

        playerUserName.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        playerUserName.setForeground(new java.awt.Color(201, 53, 96));
        playerUserName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        playerUserName.setText("Player:");

        playButton.setForeground(new java.awt.Color(70, 94, 136));
        playButton.setText("Play");
        playButton.setBorderPainted(false);
        playButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        playButton.setkBorderRadius(20);
        playButton.setkEndColor(new java.awt.Color(78, 163, 181));
        playButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        playButton.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        playButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        playButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        playButton.setkStartColor(new java.awt.Color(70, 94, 136));
        playButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playButtonActionPerformed(evt);
            }
        });

        playerScore.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        playerScore.setForeground(new java.awt.Color(201, 53, 96));
        playerScore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        playerScore.setText("Score:");

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(222, 222, 222)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(playerUserName)
                    .addComponent(playerScore))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap(125, Short.MAX_VALUE)
                .addGroup(kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(playerLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(267, 267, 267))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel1Layout.createSequentialGroup()
                        .addComponent(playButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(258, 258, 258))))
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(logoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(playerUserName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(playerScore)
                .addGap(18, 18, 18)
                .addComponent(playButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void playButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playButtonActionPerformed
        new CountOne(player).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_playButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PlayerInfoFrame(null).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel logoLabel;
    private keeptoo.KButton playButton;
    private javax.swing.JLabel playerLogo;
    private javax.swing.JLabel playerScore;
    private javax.swing.JLabel playerUserName;
    // End of variables declaration//GEN-END:variables
}
