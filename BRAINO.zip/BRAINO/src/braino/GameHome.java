package braino;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class GameHome extends javax.swing.JFrame {

    public GameHome() {
        initComponents();
        ImageIcon logo = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("logo.png")));
        Image img1 = logo.getImage();
        Image img2 = img1.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon i = new ImageIcon(img2);
        logoLabel.setIcon(i);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        logoLabel = new javax.swing.JLabel();
        startButton = new keeptoo.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        kGradientPanel1.setkEndColor(new java.awt.Color(248, 217, 132));
        kGradientPanel1.setkStartColor(new java.awt.Color(243, 185, 89));
        kGradientPanel1.setPreferredSize(new java.awt.Dimension(683, 512));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        kGradientPanel1.add(logoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 640, 250));

        startButton.setForeground(new java.awt.Color(70, 94, 136));
        startButton.setText("Start");
        startButton.setBorderPainted(false);
        startButton.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        startButton.setkBorderRadius(20);
        startButton.setkEndColor(new java.awt.Color(96, 179, 178));
        startButton.setkHoverEndColor(new java.awt.Color(96, 179, 178));
        startButton.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        startButton.setkHoverStartColor(new java.awt.Color(96, 179, 178));
        startButton.setkPressedColor(new java.awt.Color(96, 179, 178));
        startButton.setkStartColor(new java.awt.Color(70, 94, 136));
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });
        kGradientPanel1.add(startButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 150, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        new Login().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_startButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GameHome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private keeptoo.KGradientPanel kGradientPanel1;
    private javax.swing.JLabel logoLabel;
    private keeptoo.KButton startButton;
    // End of variables declaration//GEN-END:variables
}
